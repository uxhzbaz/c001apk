package com.example.c001apk.ui.login

import android.os.Bundle
import android.view.MenuItem
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import com.example.c001apk.R
import com.example.c001apk.constant.Constants
import com.example.c001apk.databinding.ActivityLoginBinding
import com.example.c001apk.ui.base.BaseActivity
import com.example.c001apk.ui.main.MainActivity
import com.example.c001apk.util.ActivityCollector
import com.example.c001apk.util.PrefManager
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class LoginActivity : BaseActivity<ActivityLoginBinding>() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setSupportActionBar(binding.toolBar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        binding.webView.apply {
            settings.javaScriptEnabled = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (url == Constants.URL_COOLAPK) {
                        val cookies = CookieManager.getInstance().getCookie(Constants.URL_COOLAPK) ?: return
                        val uid = extractCookie(cookies, "uid")
                        val username = extractCookie(cookies, "username")
                        val token = extractCookie(cookies, "token")
                        if (!uid.isNullOrEmpty() && !username.isNullOrEmpty() && !token.isNullOrEmpty()) {
                            PrefManager.isLogin = true
                            PrefManager.uid = uid
                            PrefManager.username = username
                            PrefManager.token = token
                            Toast.makeText(this@LoginActivity, "登录成功", Toast.LENGTH_SHORT).show()
                            afterLogin()
                        }
                    }
                }
            }
            loadUrl(Constants.URL_LOGIN)
        }
    }

    private fun extractCookie(cookies: String, key: String): String? {
        return cookies.split(";").find { it.trim().startsWith("$key=") }
            ?.substringAfter("=")
            ?.trim()
    }

    private fun afterLogin() {
        ActivityCollector.recreateActivity(MainActivity::class.java.name)
        finish()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) finish()
        return true
    }
}